import React from 'react';
export default function AdminPanel(){
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Admin Panel (Mobile friendly)</h1>
      <div className="mt-4 grid grid-cols-1 gap-4">
        <div className="p-4 bg-white rounded shadow">User Management (search, ban/unban)</div>
        <div className="p-4 bg-white rounded shadow">Top-up History & Manual Topup</div>
        <div className="p-4 bg-white rounded shadow">Gacha Management & Items</div>
      </div>
    </div>
  );
}
