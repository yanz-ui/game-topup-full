# Game Topup Platform — Full Package (All Features)

Ini adalah paket lengkap proyek yang dibuat sesuai permintaan:
- Frontend React (placeholder + admin components, mobile-friendly admin panel)
- Player & Owner servers (Express + SQLite/Postgres options)
- Payments: Stripe + Midtrans example + payment webhook handling
- Docker + docker-compose (Postgres DB service + frontend + servers + payments)
- CI/CD: GitHub Actions workflow to build & push Docker images
- Auto-deploy example to Render / DigitalOcean (workflow snippets)
- Email notifications (nodemailer example) and Owner 2FA via email OTP
- Admin dashboard components with charts (Recharts sample)
- Game features: Inventory, Item Shop, Gacha (pulls), Simple Battle System endpoints
- Swagger / OpenAPI docs (openapi.yaml)
- Seed script to populate DB with sample users, items, owner
- Architecture diagram (SVG) included


## Quick start (development)
1. Copy `.env.example` → `.env` and set secrets (JWT_SECRET, STRIPE keys, MAIL credentials). 
2. Run services without Docker (node): `node server-player/server_player.js`, `node server-owner/server_owner.js`, `node payments/server-payments.js`
3. Or run with Docker Compose: `docker-compose up --build` (requires Docker)

## Notes
- This repository is a starter template. Before production: secure secrets, use managed DB, enable HTTPS, review webhook secrets and validate inputs.
