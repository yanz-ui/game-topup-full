/*
Owner email + 2FA example using nodemailer. This is a minimal example.
*/
const nodemailer = require('nodemailer');
const otpStore = {};
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_PASS }
});

function generateOTP(email){
  const otp = Math.floor(100000 + Math.random()*900000).toString();
  otpStore[email] = otp;
  transporter.sendMail({ from: process.env.MAIL_USER, to: email, subject: 'OTP Login', text: 'Your OTP: ' + otp });
  return otp;
}

function verifyOTP(email, code){
  return otpStore[email] && otpStore[email] === code;
}

module.exports = { generateOTP, verifyOTP };
