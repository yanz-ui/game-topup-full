/*
Seed script for SQLite (or Postgres if modified).
Adjust for your DB choice. This script is a simple example to create owner, players, items.
Run: node scripts/seed.js
*/
const Database = require('better-sqlite3');
const path = require('path');
const dbfile = path.join(__dirname, '../data/game-topup.db');
const db = new Database(dbfile);

db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, email TEXT UNIQUE, password_hash TEXT, balance INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS owners (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, password_hash TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, price INTEGER, rarity TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS inventories (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, item_id INTEGER, quantity INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS topups (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, owner_id INTEGER, amount INTEGER, note TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
`);

const bcrypt = require('bcrypt');
const ownerPass = bcrypt.hashSync('ownerpass',10);
db.prepare('INSERT OR IGNORE INTO owners (email,password_hash) VALUES (?,?)').run('owner@example.com', ownerPass);

const uPass = bcrypt.hashSync('playerpass',10);
db.prepare('INSERT OR IGNORE INTO users (username,email,password_hash,balance) VALUES (?,?,?,?)').run('player1','player1@example.com',uPass,1000);

db.prepare('INSERT OR IGNORE INTO items (name,price,rarity) VALUES (?,?,?)').run('Sword',100,'common');
db.prepare('INSERT OR IGNORE INTO items (name,price,rarity) VALUES (?,?,?)').run('Shield',150,'common');
db.prepare('INSERT OR IGNORE INTO items (name,price,rarity) VALUES (?,?,?)').run('Excalibur',10000,'legendary');

console.log('Seed completed.');
